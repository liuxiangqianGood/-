package com.qian.hehemsg.api;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.springframework.stereotype.Component;

/**
 * @author Xiangqian Liu
 * @createTime 2022-08-22 13:22:00
 * @Description 天气接口
 */
public class WeatherApi {

    /**
     * 天气接口
     * */
    public static String getWeather(String cityId) throws Exception{

        CloseableHttpClient httpClient= HttpClients.createDefault();
        StringBuilder stringBuilder=new StringBuilder();
        stringBuilder.append("https://v0.yiketianqi.com/api?unescape=1&version=v91&appid=43656176&appsecret=I42og6Lm&ext=&city=&cityid="+cityId);
        HttpGet httpGet=new HttpGet(stringBuilder.toString());
        CloseableHttpResponse response=httpClient.execute(httpGet);
        HttpEntity httpEntity= response.getEntity();
        String result= EntityUtils.toString(httpEntity);
        JSONObject object=JSONObject.fromObject(result);
        JSONArray array=object.getJSONArray("data");
        JSONObject arrayObject=array.getJSONObject(0);
        //日期
        String day=arrayObject.getString("day");
        //天气
        String wea=arrayObject.getString("wea");
        //当前温度
        String tem=arrayObject.getString("tem");
        //最高气温
        String tem1=arrayObject.getString("tem1");
        //最低气温
        String tem2=arrayObject.getString("tem2");
        //天气信息
        String narrative=arrayObject.getString("narrative");

        String Weather=day+" "+wea+" "+"今日温度:"+tem2+"~"+tem1+"度"+" "+narrative;

        return Weather;
    }
}
