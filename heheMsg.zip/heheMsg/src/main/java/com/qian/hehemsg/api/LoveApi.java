package com.qian.hehemsg.api;

import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.springframework.stereotype.Component;

/**
 * @author Xiangqian Liu
 * @createTime 2022-08-22 13:23:00
 * @Description 情话接口
 */
public class LoveApi {

    public static String getLoveMsg() throws Exception{

        CloseableHttpClient httpClient= HttpClients.createDefault();
        StringBuilder stringBuilder=new StringBuilder();
        stringBuilder.append("https://api.lovelive.tools/api/SweetNothings");
        HttpGet httpGet=new HttpGet(stringBuilder.toString());
        httpGet.setHeader("token","LwExDtUWhF3rH5ib");
        CloseableHttpResponse response=httpClient.execute(httpGet);
        HttpEntity httpEntity= response.getEntity();
        String result= EntityUtils.toString(httpEntity);

        return result;
    }
}
