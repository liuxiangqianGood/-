package com.qian.hehemsg.util;

import com.qian.hehemsg.service.WxTemplateService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @author Xiangqian Liu
 * @createTime 2022-08-22 13:18:00
 * @Description 定时类
 */
@Component
@Slf4j
public class SysTask {

    @Resource
    WxTemplateService wxTemplateService;

    /**
     * 定时推送
     * */
    @Scheduled(cron = "0 0 10 * * ? ")
    public void taskPush(){
        log.info("消息推送定时任务启动");
        wxTemplateService.pushWxTemplateForMyLove();
    }

}
