package com.qian.hehemsg.enumutil;

import lombok.Data;

/**
 * @author Xiangqian Liu
 * @createTime 2022-08-23 09:25:00
 * @Description 微信信息配置枚举类
 */
public enum WxInformation {

    wx("","","","","","LwExDtUWhF3rH5ib","101130901","101210101");


    WxInformation(String appId,String secret,String openId,String startLoveTime,String birthdayTime,String loveMsgToken,String KaShiCityId,String HangZhouCityId){

        this.appId=appId;
        this.secret=secret;
        this.openId=openId;
        this.startLoveTime=startLoveTime;
        this.birthdayTime=birthdayTime;
        this.loveMsgToken=loveMsgToken;
        this.KaShiCityId=KaShiCityId;
        this.HangZhouCityId=HangZhouCityId;
    }

    private String openId;  //openId

    private String appId;   //公众号appId

    private String secret;  //公众号secret

    private String loveMsgToken;    //情话第三方接口token(可以选择不用改动)

    private String startLoveTime;   //开始恋爱时间

    private String birthdayTime;    //生日,月日(例如03-12)

    private String KaShiCityId;     //喀什cityId

    private String HangZhouCityId;  //杭州cityId(可以在天气接口查询到)

    public String getKaShiCityId() {
        return KaShiCityId;
    }

    public void setKaShiCityId(String kaShiCityId) {
        KaShiCityId = kaShiCityId;
    }

    public String getHangZhouCityId() {
        return HangZhouCityId;
    }

    public void setHangZhouCityId(String hangZhouCityId) {
        HangZhouCityId = hangZhouCityId;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public String getLoveMsgToken() {
        return loveMsgToken;
    }

    public void setLoveMsgToken(String loveMsgToken) {
        this.loveMsgToken = loveMsgToken;
    }

    public String getStartLoveTime() {
        return startLoveTime;
    }

    public void setStartLoveTime(String startLoveTime) {
        this.startLoveTime = startLoveTime;
    }

    public String getBirthdayTime() {
        return birthdayTime;
    }

    public void setBirthdayTime(String birthdayTime) {
        this.birthdayTime = birthdayTime;
    }
}
