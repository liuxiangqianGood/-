package com.qian.hehemsg.api;

import com.qian.hehemsg.enumutil.WxInformation;
import net.sf.json.JSONObject;
import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.springframework.stereotype.Component;


/**
 * @author Xiangqian Liu
 * @createTime 2022-08-22 14:48:00
 * @Description 微信api
 */
public class WxApi {

    public static String queryAccessToken() throws Exception{

                String accessToken=new String();

                String appId=WxInformation.wx.getAppId();
                String secret= WxInformation.wx.getSecret();
                CloseableHttpClient httpClient= HttpClients.createDefault();
                StringBuffer stringBuffer=new StringBuffer();
                stringBuffer.append("https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential");
                stringBuffer.append("&appid="+appId);
                stringBuffer.append("&secret="+secret);
                HttpGet httpGet=new HttpGet(stringBuffer.toString());
                CloseableHttpResponse response=httpClient.execute(httpGet);
                HttpEntity httpEntity=response.getEntity();
                String result= EntityUtils.toString(httpEntity,"UTF-8");

                JSONObject jsonObject= JSONObject.fromObject(result);
                accessToken=jsonObject.getString("access_token");
                httpClient.close();
                response.close();

                return accessToken;
    }
}
